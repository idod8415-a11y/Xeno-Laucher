package com.mylauncher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.net.URL

object MojangApi {
    val json = Json { ignoreUnknownKeys = true }
    private const val MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

    suspend fun loadVersions(): List<VersionEntry> = withContext(Dispatchers.IO) {
        json.decodeFromString<Manifest>(URL(MANIFEST).readText()).versions
    }

    suspend fun loadVersionJson(entry: VersionEntry): VersionJson = withContext(Dispatchers.IO) {
        json.decodeFromString<VersionJson>(URL(entry.url).readText())
    }
}
