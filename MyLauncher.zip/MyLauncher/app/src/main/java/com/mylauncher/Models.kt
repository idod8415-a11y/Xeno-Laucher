package com.mylauncher

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

@Serializable data class VersionEntry(val id: String, val type: String, val url: String)
@Serializable data class Manifest(val versions: List<VersionEntry>)

@Serializable data class Artifact(val path: String? = null, val sha1: String? = null, val url: String)
@Serializable data class LibDownloads(val artifact: Artifact? = null)
@Serializable data class Rule(val action: String, val os: JsonObject? = null)
@Serializable data class Library(
    val name: String,
    val downloads: LibDownloads? = null,
    val rules: List<Rule>? = null
)
@Serializable data class AssetIndexRef(val id: String, val url: String)
@Serializable data class JavaVer(val majorVersion: Int = 8)
@Serializable data class Downloads(val client: Artifact)

@Serializable data class VersionJson(
    val id: String,
    val mainClass: String,
    val type: String = "release",
    val libraries: List<Library>,
    val assetIndex: AssetIndexRef,
    val downloads: Downloads,
    val javaVersion: JavaVer? = null,
    val minecraftArguments: String? = null,   // старый формат (до 1.13)
    val arguments: JsonObject? = null          // новый формат
)

@Serializable data class AssetObj(val hash: String)
@Serializable data class AssetIndex(val objects: Map<String, AssetObj>)
