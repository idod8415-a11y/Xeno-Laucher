package com.mylauncher

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.util.UUID

class LaunchSpec(val javaMajor: Int, val args: List<String>, val workDir: File)

object LaunchArgs {
    fun build(v: VersionJson, dl: Downloader, gameDir: File, player: String, ramMb: Int): LaunchSpec {
        val cp = (dl.libraryList(v).map { File(dl.libsDir, it.downloads!!.artifact!!.path ?: it.name).path } +
                dl.clientJar(v).path).joinToString(":")

        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$player".toByteArray()).toString()
        val vars = mapOf(
            "auth_player_name" to player, "version_name" to v.id,
            "game_directory" to gameDir.path, "assets_root" to dl.assetsDir.path,
            "game_assets" to dl.assetsDir.path, "assets_index_name" to v.assetIndex.id,
            "auth_uuid" to uuid, "auth_access_token" to "0", "auth_session" to "0",
            "user_type" to "legacy", "version_type" to v.type, "user_properties" to "{}",
            "clientid" to "", "auth_xuid" to ""
        )
        fun sub(s: String) = Regex("\\$\\{(\\w+)}").replace(s) { vars[it.groupValues[1]] ?: "" }

        val game: List<String> = if (v.minecraftArguments != null) {
            v.minecraftArguments.split(" ")
        } else {
            val arr: JsonArray = v.arguments?.get("game")?.jsonArray ?: JsonArray(emptyList())
            arr.filterIsInstance<JsonPrimitive>().map { it.jsonPrimitive.content }
        }

        val args = buildList {
            add("-Xmx${ramMb}M")
            add("-cp"); add(cp)
            add(v.mainClass)
            addAll(game.map(::sub))
        }
        return LaunchSpec(v.javaVersion?.majorVersion ?: 8, args, gameDir)
    }
}
