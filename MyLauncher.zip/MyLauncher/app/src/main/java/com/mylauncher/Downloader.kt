package com.mylauncher

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

class Downloader(private val root: File) {
    val libsDir = File(root, "libraries")
    val assetsDir = File(root, "assets")
    val versionsDir = File(root, "versions")

    private fun fetch(url: String, dest: File) {
        if (dest.exists() && dest.length() > 0) return
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        URL(url).openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        tmp.renameTo(dest)
    }

    private fun libAllowed(lib: Library): Boolean {
        val rules = lib.rules ?: return true
        var allowed = false
        for (r in rules) {
            val os = r.os?.get("name")?.toString()?.trim('"')
            if (os == null || os == "linux") allowed = r.action == "allow"
        }
        return allowed
    }

    /** Библиотеки для classpath. LWJGL пропускаем: свою версию даёт Pojav. */
    fun libraryList(v: VersionJson): List<Library> = v.libraries.filter {
        libAllowed(it) && it.downloads?.artifact != null && !it.name.startsWith("org.lwjgl")
    }

    fun clientJar(v: VersionJson) = File(versionsDir, "${v.id}/${v.id}.jar")

    suspend fun downloadAll(v: VersionJson, onProgress: (String) -> Unit) = withContext(Dispatchers.IO) {
        onProgress("Клиент ${v.id}…")
        fetch(v.downloads.client.url, clientJar(v))

        val libs = libraryList(v)
        val done = AtomicInteger(0)
        val sem = Semaphore(8)
        coroutineScope {
            libs.map { lib ->
                async {
                    sem.withPermit {
                        val a = lib.downloads!!.artifact!!
                        fetch(a.url, File(libsDir, a.path ?: lib.name))
                        onProgress("Библиотеки ${done.incrementAndGet()}/${libs.size}")
                    }
                }
            }.awaitAll()
        }

        onProgress("Список ресурсов…")
        val idxFile = File(assetsDir, "indexes/${v.assetIndex.id}.json")
        fetch(v.assetIndex.url, idxFile)
        val idx = MojangApi.json.decodeFromString<AssetIndex>(idxFile.readText())
        val total = idx.objects.size
        val n = AtomicInteger(0)
        coroutineScope {
            idx.objects.values.distinctBy { it.hash }.map { obj ->
                async {
                    sem.withPermit {
                        val p = obj.hash.substring(0, 2)
                        fetch("https://resources.download.minecraft.net/$p/${obj.hash}",
                            File(assetsDir, "objects/$p/${obj.hash}"))
                        val c = n.incrementAndGet()
                        if (c % 50 == 0) onProgress("Ресурсы $c/$total")
                    }
                }
            }.awaitAll()
        }
        onProgress("Загрузка завершена")
    }
}
