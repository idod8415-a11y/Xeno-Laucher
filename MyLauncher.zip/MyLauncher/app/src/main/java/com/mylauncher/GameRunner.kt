package com.mylauncher

import android.app.Activity

/** Точка стыка с ядром Pojav. */
interface GameRunner {
    fun run(activity: Activity, spec: LaunchSpec)
}

/**
 * ЗАГЛУШКА. Здесь нужно вызвать запуск JVM из форка PojavLauncher:
 *  1) распаковать нужный JRE (spec.javaMajor: 8 / 17 / 21) из assets;
 *  2) выставить окружение рендерера (gl4es / Zink / ANGLE) и LWJGL от Pojav;
 *  3) вызвать нативный JVM-запуск (в Pojav это JREUtils.launchJavaVM) с spec.args.
 */
class PojavRunner : GameRunner {
    override fun run(activity: Activity, spec: LaunchSpec) {
        error("Подключите ядро Pojav: см. GameRunner.kt. Аргументы: ${spec.args.joinToString(" ")}")
    }
}
