package com.mylauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Screen() } } }
    }

    @Composable
    fun Screen() {
        val scope = rememberCoroutineScope()
        var versions by remember { mutableStateOf<List<VersionEntry>>(emptyList()) }
        var filter by remember { mutableStateOf("release") }
        var selected by remember { mutableStateOf<VersionEntry?>(null) }
        var name by remember { mutableStateOf("Player") }
        var status by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            status = "Загрузка списка версий…"
            status = try { versions = MojangApi.loadVersions(); "" } catch (e: Exception) { "Ошибка сети: ${e.message}" }
        }

        Column(Modifier.fillMaxSize().padding(16.dp).statusBarsPadding()) {
            Text("My Launcher", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name, { name = it }, label = { Text("Ник") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("release" to "Релизы", "snapshot" to "Снапшоты",
                    "old_beta" to "Бета", "old_alpha" to "Альфа").forEach { (k, l) ->
                    FilterChip(filter == k, { filter = k }, label = { Text(l) })
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(versions.filter { it.type == filter }) { v ->
                    Text(v.id,
                        color = if (v == selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth().clickable { selected = v }.padding(12.dp))
                }
            }
            if (status.isNotEmpty()) Text(status)
            Button(
                enabled = selected != null && !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val entry = selected ?: return@Button
                    busy = true
                    scope.launch {
                        try {
                            val root = filesDir
                            val dl = Downloader(root)
                            val vj = MojangApi.loadVersionJson(entry)
                            dl.downloadAll(vj) { status = it }
                            val spec = LaunchArgs.build(vj, dl, root.resolve("game"), name, 2048)
                            spec.workDir.mkdirs()
                            PojavRunner().run(this@MainActivity, spec)
                        } catch (e: Throwable) {
                            status = "Ошибка: ${e.message}"
                        } finally { busy = false }
                    }
                }
            ) { Text(if (busy) "Подождите…" else "Играть ${selected?.id ?: ""}") }
        }
    }
}
