# MyLauncher
Каркас лаунчера Minecraft Java для Android (Kotlin + Compose).

Уже работает: список ВСЕХ версий (release/snapshot/beta/alpha), скачивание клиента,
библиотек и ресурсов, сборка аргументов запуска, выбор Java по версии.

Осталось: подключить ядро Pojav в GameRunner.kt (JRE 8/17/21, рендерер, LWJGL, запуск JVM),
затем Microsoft-вход, моды, настройки.
Сборка: залей в GitHub, Actions соберёт APK (вкладка Actions -> Artifacts).
